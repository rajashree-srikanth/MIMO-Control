# fusion

[The ION Program] Project FUSION: Autonomous Landing of Model Rockets