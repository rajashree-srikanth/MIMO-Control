clear all;
close all;

%% drone parameters for this problem
chardonnay.m_d = 1;
chardonnay.m_c = 1;
chardonnay.l = 1;
chardonnay.l_d = 1;
chardonnay.J = 0.1;
chardonnay.C_D = 0.1;
chardonnay.g = 10;

%% controller design (Prof. Lustosa Example - bad design)
K = [ ...
   -2.2361   -2.2361   -3.1109   -2.1804   19.2981    8.2189   38.3907    9.8868;
    2.2361   -2.2361    3.1109   -2.1804  -19.2981   -8.2189  -38.3907   -9.8868 ];

%% simulation from simulink, animation and display of final water level
% DO NOT MODIFY THIS SECTION!!!!

out = sim('chardonnay_simulinkR2018a', 'ReturnWorkspaceOutputs', 'on');

t = out.simout.Time;
r = out.simout.Data(:,1:2)';
r(2,:) = -r(2,:);
the = out.simout.Data(:,5)';
gam = out.simout.Data(:,7)';

% print water level
chardonnay_animate(chardonnay, t, r, the, gam);
